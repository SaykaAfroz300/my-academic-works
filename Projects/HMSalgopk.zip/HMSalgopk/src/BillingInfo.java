import java.util.ArrayList;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sayka
 */
public class BillingInfo {
  
    Patient patient;
    ArrayList<Medicine> medicines;
    String reccomendations,date;
    int fee;

    public BillingInfo() {
        this.patient = null;
        this.medicines = new ArrayList<>();
        this.reccomendations = "";
        this.date = "";
        this.fee = 0;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public ArrayList<Medicine> getMedicine() {
        return medicine;
    }

    public void setMedicine(Medicine medicines) {
        this.medicines.add(medicines);
    }

    public String getReccomendations() {
        return reccomendations;
    }

    public void setReccomendations(String reccomendations) {
        this.reccomendations = reccomendations;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }
    
    
    
}
