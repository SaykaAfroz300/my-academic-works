
package sms;


public class Student {
    String id, name, password,city,dob, gender;

    public Student(String id, String name, String password, String city, String dob, String gender) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.city = city;
        this.dob = dob;
        this.gender = gender;
    }

    
}
