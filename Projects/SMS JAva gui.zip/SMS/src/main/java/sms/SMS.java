/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sms;


public class SMS {

    public static void main(String[] args) {
       SF f = new SF();
       f.setVisible(true);
    }
}
